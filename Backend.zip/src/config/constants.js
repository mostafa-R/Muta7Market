export const USER_ROLES = {
  SUPER_ADMIN: "super_admin",
  ADMIN: "admin",
  USER: "user",
};

export const PROFILE_STATUS = {
  AVAILABLE: "available",
  TRANSFERRED: "transferred",
  RECENLYTRANSFARRED: "recently transferred",
  CONTRACTED: "contracted",
};

export const GENDER = {
  MALE: "male",
  FEMALE: "female",
};

export const CATEGORY = {
  PLAYER: "player",
  COACH: "coach",
};

export const PAYMENT_STATUS = {
  PENDING: "pending",
  COMPLETED: "completed",
  FAILED: "failed",
  REFUNDED: "refunded",
};

export const OFFER_STATUS = {
  ACTIVE: "active",
  INACTIVE: "inactive",
  EXPIRED: "expired",
  PENDING: "pending",
};

export const NOTIFICATION_TYPES = {
  EMAIL: "email",
  SMS: "sms",
  PUSH: "push",
};

// كل الأسعار لسنة كاملة
export const PRICING = {
  // يوزر يدفع سنة ليفتح وسائل التواصل
  contacts_access_year: 5,

  // اشتراك الظهور في الليست لسنة
  listing_year: {
    player: 5,
    coach: 5,
  },

  // PRICE_CONTACTS_ACCESS=200
  // PRICE_CONTACTS_ACCESS_YEAR=200
  // PRICE_LISTING_PLAYER_YEAR=190
  // PRICE_LISTING_COACH_YEAR=140
  // PRICE_PROMO_PLAYER_YEAR=100
  // PRICE_PROMO_COACH_YEAR=100
  // ONE_YEAR_DAYS=365

  // ترقية التوب ليست لسنة
  promotion_year: {
    player: 5,
    coach: 5,
  },

  // مدة الترويج: 15 يوم (يمكن تعديل هذا الرقم فقط)
  PROMOTION_DAYS: 15,

  // مدة الاشتراكات: 365 يوم
  ONE_YEAR_DAYS: 365,
};

export const PAGINATION = {
  DEFAULT_PAGE: 1,
  DEFAULT_LIMIT: 10,
  MAX_LIMIT: 100,
};
