import mongoose from "mongoose";
import { GENDER, PROFILE_STATUS } from "../config/constants.js";

const mediaVideoSchema = new mongoose.Schema(
  {
    url: { type: String, default: null },
    publicId: { type: String, default: null },
    title: { type: String, default: null },
    duration: { type: Number, default: 0, min: 0 },
    uploadedAt: { type: Date, default: Date.now },
  },
  { _id: false }
);

const mediaDocumentSchema = new mongoose.Schema(
  {
    url: { type: String, default: null },
    publicId: { type: String, default: null },
    title: { type: String, default: null },
    type: { type: String, default: null },
    size: { type: Number, default: 0, min: 0 },
    uploadedAt: { type: Date, default: Date.now },
  },
  { _id: false }
);

const mediaImageSchema = new mongoose.Schema(
  {
    url: { type: String, default: null },
    publicId: { type: String, default: null },
    title: { type: String, default: null },
    type: { type: String, default: null },
    size: { type: Number, default: 0, min: 0 },
    uploadedAt: { type: Date, default: Date.now },
  },
  { _id: false }
);

const playerSchema = new mongoose.Schema(
  {
    isListed: {
      type: Boolean,
      default: false,
      index: true,
    },
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    name: {
      type: String,
      required: true,
      trim: true, // Remove leading/trailing whitespace
    },
    age: {
      type: Number,
      required: true,
      min: 15,
      max: 50,
    },
    gender: {
      type: String,
      enum: Object.values(GENDER),
      required: true,
    },
    nationality: {
      type: String,
      required: true,
      trim: true,
    },
    customNationality: {
      type: String,
      default: null,
      trim: true,
    },
    birthCountry: {
      type: String,
      default: null,
      trim: true,
    },
    customBirthCountry: {
      type: String,
      default: null,
      trim: true,
    },
    jop: {
      type: String,
      enum: ["player", "coach"], // Restrict to specific values
      required: true,
    },
    roleType: {
      type: String,
      default: null,
      trim: true,
    },
    customRoleType: {
      type: String,
      default: null,
      trim: true,
    },
    position: {
      type: String,

      trim: true,
    },
    customPosition: {
      type: String,
      default: null,
      trim: true,
    },
    status: {
      type: String,
      enum: Object.values(PROFILE_STATUS),
      default: PROFILE_STATUS.AVAILABLE,
    },
    experience: {
      type: Number,
      default: 0,
      min: 0,
    },
    monthlySalary: {
      amount: { type: Number, default: 0, min: 0 },
      currency: { type: String, default: "SAR" },
    },
    yearSalary: {
      amount: { type: Number, default: 0, min: 0 },
      currency: { type: String, default: "SAR" },
    },
    contractEndDate: {
      type: Date,
      default: null, // Explicit default for clarity
    },
    transferredTo: {
      club: { type: String, default: null },
      startDate: { type: Date, default: null },
      endDate: { type: Date, default: null },
      amount: { type: Number, default: 0, min: 0 },
    },

    socialLinks: {
      instagram: { type: String, default: null },
      twitter: { type: String, default: null },
      whatsapp: { type: String, default: null },
      youtube: { type: String, default: null },
    },

    contactInfo: {
      email: { type: String, default: null },
      phone: { type: String, default: null },
      agent: {
        name: { type: String, default: null },
        phone: { type: String, default: null },
        email: { type: String, default: null },
      },
    },

    isPromoted: {
      status: { type: Boolean, default: false },
      startDate: { type: Date, default: null },
      endDate: { type: Date, default: null },
      type: { type: String, default: null },
    },

    media: {
      profileImage: {
        url: { type: String, default: null },
        publicId: { type: String, default: null },
      },
      video: {
        type: mediaVideoSchema,
        default: () => ({
          url: null,
          publicId: null,
          title: null,
          duration: 0,
          uploadedAt: null,
        }),
      },
      document: {
        type: mediaDocumentSchema,
        default: () => ({
          url: null,
          publicId: null,
          title: null,
          type: null,
          size: 0,
          uploadedAt: null,
        }),
      },
      images: {
        type: [mediaImageSchema],
        default: () => [
          {
            url: null,
            publicId: null,
            title: null,
            type: null,
            size: 0,
          },
        ],
      },
    },

    game: {
      type: String,
      required: true,
      trim: true,
    },
    customSport: {
      type: String,
      default: null,
      trim: true,
    },
    views: {
      type: Number,
      default: 0,
      min: 0,
    },
    isActive: {
      type: Boolean,
      default: false,
    },
    isConfirmed: {
      type: Boolean,
      default: false,
    },
  },
  {
    timestamps: true,
    toJSON: {
      virtuals: true,
      transform: function (doc, ret) {
        // اختفاء سحري للـ "other" - استبدال القيم في نفس الـ fields

        // إذا nationality = "other" اعرض customNationality بدلاً منها
        if (ret.nationality === "other" && ret.customNationality) {
          ret.nationality = ret.customNationality;
        }

        // إذا birthCountry = "other" اعرض customBirthCountry بدلاً منها
        if (ret.birthCountry === "other" && ret.customBirthCountry) {
          ret.birthCountry = ret.customBirthCountry;
        }

        // إذا roleType = "other" اعرض customRoleType بدلاً منها
        if (ret.roleType === "other" && ret.customRoleType) {
          ret.roleType = ret.customRoleType;
        }

        // إذا position = "other" اعرض customPosition بدلاً منها
        if (ret.position === "other" && ret.customPosition) {
          ret.position = ret.customPosition;
        }

        // إذا game = "other" اعرض customSport بدلاً منها
        if (ret.game === "other" && ret.customSport) {
          ret.game = ret.customSport;
        }

        return ret;
      },
    },
  }
);

// Indexes for optimized queries
playerSchema.index({ name: "text", position: "text" }); // Text search for name and position
playerSchema.index({ nationality: 1, jop: 1, status: 1 }); // Compound index for filtering
playerSchema.index({ "isPromoted.status": 1, "isPromoted.endDate": 1 }); // Index for promoted players
playerSchema.index({ game: 1 }); // Index for game-based queries

// Virtual for checking if promoted
playerSchema.virtual("isCurrentlyPromoted").get(function () {
  return (
    this.isPromoted.status &&
    this.isPromoted.endDate &&
    this.isPromoted.endDate > new Date()
  );
});

// Method to promote player
playerSchema.methods.promote = async function (days, type = "featured") {
  this.isPromoted = {
    status: true,
    startDate: new Date(),
    endDate: new Date(Date.now() + days * 24 * 60 * 60 * 1000),
    type,
  };
  return this.save();
};

// Method to transfer player
playerSchema.methods.transfer = async function (clubName, amount) {
  this.status = PROFILE_STATUS.TRANSFERRED;
  this.transferredTo = {
    club: clubName,
    date: new Date(),
    amount,
  };
  return this.save();
};

playerSchema.pre("validate", function (next) {
  if (this.status) {
    this.status = this.status.toLowerCase();
  }
  next();
});

export default mongoose.model("Player", playerSchema);
