import SignInForm from "@/components/auth/SignInForm";

export const metadata = {
  title: "SignIn Page | Admin Dashboard ",
  description: "SignIn Page | Admin Dashboard ",
};

export default function SignIn() {
  return <SignInForm />;
}
