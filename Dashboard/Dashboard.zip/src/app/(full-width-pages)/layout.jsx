export default function FullWidthPageLayout({ children }) {
  return <div>{children}</div>;
}
